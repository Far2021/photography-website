### photo-gallery-img-template
### https://it-services-web-dev.netlify.com/w3-parallax.html <br> 
or <br>
### https://chasesinghofen.github.io/chasesinghofen/compact-gallery.html
12/26/2019:: uploaded second option for photography website

![image](https://user-images.githubusercontent.com/23155302/71473177-04fc8800-27a4-11ea-80a5-eea1e01e4781.png)

12/19/2019:: added second optional template (w3css responsive version) with LightBox feature for images. 

<img width="958" alt="h-scroll-img" src="https://user-images.githubusercontent.com/23155302/71211750-c899cb00-227d-11ea-862c-e13935c91754.PNG">
<img width="951" alt="h-scroll-img-lightbox" src="https://user-images.githubusercontent.com/23155302/71211754-c9caf800-227d-11ea-9412-f5d26552687c.PNG">


Photo img gallery, bootstrap 4, fully responsive Includes contact form and mailto: links for sending emails. Template contains: grid, card, & fluid gallery's, horizontal img gallery, bootstrap 4 carousel, & img grid with img descriptions. includes css ease-in-out animations. Click on any photo in the grid, card, & fluid gallery's to view photos in a lightbox.  Navigate the template easy with the fixed navbar. No need for continuous scrolling to view sections of webpage. 

![image](https://user-images.githubusercontent.com/23155302/41195274-0883bfca-6bf8-11e8-9c35-f7b4c5c642a4.png)

![image](https://user-images.githubusercontent.com/23155302/41195278-1baeef66-6bf8-11e8-8efe-e6c71975eac0.png)

![image](https://user-images.githubusercontent.com/23155302/41195281-30b50260-6bf8-11e8-8353-bd003282a602.png)

![image](https://user-images.githubusercontent.com/23155302/41195287-45daeb1e-6bf8-11e8-98f4-0180ae934889.png)

![image](https://user-images.githubusercontent.com/23155302/41195295-5b8a904a-6bf8-11e8-85c0-fe2d327b2fdb.png)

![image](https://user-images.githubusercontent.com/23155302/41195299-70d2f474-6bf8-11e8-876c-fd6666837529.png)

![image](https://user-images.githubusercontent.com/23155302/41195307-89421e54-6bf8-11e8-96ef-63c733c64143.png)

![image](https://user-images.githubusercontent.com/23155302/41195317-b5240078-6bf8-11e8-934e-19123f69558e.png)

